import React from 'react';
import Header from '../components/Header'
import Footer from '../components/Footer'
import Aside from '../components/Aside'
import { useHistory } from "umi";
import './index.less'

export default function index(props) {
  const history = useHistory()
  return (
    <div>
      <Header></Header>
      {history.location.pathname == '/' ? <div className="aside"><Aside></Aside></div>:null}
      <div className="content">{props.children}</div>
      <Footer></Footer>
    </div>
  );
}
