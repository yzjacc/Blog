import React from 'react';
import Content from '../../components/Content'

export default () => {
  return (
    <div>
        <Content></Content>
    </div>
  );
}
