import React,{ useEffect, PureComponent } from 'react';
import { connect } from "dva"
import MDRender from '../components/Markdown'
import { NavLink } from 'umi'
import styles from '../components/Content/index.less';

class Blog extends PureComponent{

  constructor(props){
    super(props);
  }

  componentWillMount(){
    this.props.onGetContents()
  }

  render(){
    let content
    for(let i = 0; i < this.props.total; i++){
      if(this.props.content[i].id == this.props.match.params.id) {
        content =  this.props.content[i].content;
        break;
      }
    }
    return (
      <div>
        <div><MDRender content={content} isBase64={false} /></div>
        <div >{this.props.content[this.state.n].id}</div>
      </div>)
  }
}

const mapStateToProps = state => ({
  content: state.essay.blogs,
  total: state.essay.blogCount
})

const mapDispatchToProps = dispatch => ({
  onGetContents() {
    dispatch({ type: "essay/getContents"})
  }
})

export default connect(mapStateToProps, mapDispatchToProps)(Blog);
