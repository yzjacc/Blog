import React from 'react'
import { NavLink, history} from 'umi'
import styles from './index.less'
export default function Menu() {
    return (
        <div className={styles.footer}>
            <div>YZJ ©2020 Created by React</div>
        </div>
    )
}
