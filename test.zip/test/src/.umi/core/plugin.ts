import { Plugin } from '/Users/yuzijun/Desktop/Github/Blog/test/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['patchRoutes','rootContainer','render','onRouteChange',],
});

export { plugin };
